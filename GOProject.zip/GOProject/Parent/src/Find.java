import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Find {
	public static void main(String[] args) throws IOException {

		String input, id, line, input1, line1, line2, line3;
		Scanner user = new Scanner(System.in);
		System.out.println("Please enter your GO term: ");
		input = user.next();
		input1 = input + "=";
		// System.out.println(input);
		// File contains all the Go terms and corresponding parent terms which
		// is created by running merge.java
		Scanner file = new Scanner(new File("C:\\Go_project\\Mergefiles.txt"));

		while (file.hasNext())

		{

			id = file.next();
			if (input1.equals(id))

			{
				line = file.nextLine();
				System.out.println("Parent of the given go term " + input + " is" + line);
				parent(line);
			}

		}

	}

	public static void parent(String s) throws IOException {
		Scanner file = new Scanner(new File("C:\\Go_project\\Mergefiles.txt"));
		String id;
		String sep = s.replaceAll("\\s", "");
		String[] sepArray = sep.split(",");

		for (int i = 0; i < sepArray.length; i++) {

			if (!sepArray[i].equals("GO:0008150") && !sepArray[i].equals("GO:0003674")) {
				String s1 = sepArray[i] + "=";
				// System.out.println(sepArray[i]);
				while (file.hasNext()) {
						id = file.next();
					if (s1.equals(id)) {
						s = file.nextLine();
						
							System.out.println(s);
						parent(s);
						for(int j=0; j<sepArray.length;j++) {
					        BufferedReader bo = new BufferedReader(new InputStreamReader(System.in));
						    String name = bo.readLine();
						    sepArray[j] = name;
						    System.out.println(sepArray);
						}
					   
						break;
					}
				}

			}

		}
	}
}
