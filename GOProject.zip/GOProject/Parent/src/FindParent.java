import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
//Class Program to find the Parent

public class FindParent {
    //To separate the file according to mf, bp, cc

    public void FileSeperate(String name) throws FileNotFoundException {
        boolean oneoccur;
        boolean molecular;
        boolean isa;
        boolean go_id;
        boolean obsolete;
        String[] content = new String[10];
        String id = "id:";
        String namespace = name;
        String isobsolete = "is_obsolete: true";
        String term = "[Term]";
        String alt_id = "alt_id:";
        String is_a = "is_a:";

        List<String> parent = new ArrayList<>();
        //Using Tree Map Algorithm
        Map<String, List<String>> map = new TreeMap<>();
        //go.obo file which contains all the GO terms and details
        File fil = new File("C:\\Go_project\\go.obo.txt");

        Scanner scan = new Scanner(fil);
        molecular = false;
        isa = false;
        oneoccur = true;

        go_id = true;
        obsolete = false;
        //Check for the conditions to separate the Go file
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            if (line.contains(term) && (oneoccur == true)) {
                molecular = false;
                isa = false;
                oneoccur = false;

                go_id = true;
            } else {
                //Check for the conditions to find parents(is_a) and Corresponding GO term
                if (line.contains(term) && (oneoccur == false)) {
                    if ((molecular == true) && (isa == true)) {
                        molecular = false;
                        go_id = true;
                        obsolete = false;
                        isa = false;

                        List<String> list = new ArrayList<String>();
                        list.addAll(parent);
                        map.put(content[1], list);
                        parent.clear();
                    } else {
                        if ((molecular == true) && (isa == false) && (obsolete == false)) {
                            molecular = false;
                            isa = false;
                            go_id = true;
                            obsolete = false;
                            List<String> list = new ArrayList<String>();
                            list.addAll(parent);
                            map.put(content[1], list);
                            parent.clear();
                        } else {
                            molecular = false;
                            go_id = true;
                            obsolete = false;
                            isa = false;

                        }
                    }
                }
            }
            if (!line.contains(alt_id)) {
                if (line.contains(id) && (go_id == true)) {
                    content = line.split(id, 2);
                    go_id = false;
                } else {
                    if (line.contains(namespace)) {
                        molecular = true;
                    }
                    if (line.contains(isobsolete) && (molecular == true)) {
                        obsolete = true;
                    } else {
                        if (line.contains(is_a) && (molecular == true)) {

                            String[] details1 = line.split("!");
                            String[] details2 = details1[0].split(is_a);
                            parent.add(details2[1]);
                            isa = true;
                        }
                    }

                }
            }
        }
        String str = mapToString(map);
        try {
            File out;
            //Output file of Go ID and their Parents of cc
            if (name == "namespace: cellular_component") {
                out = new File("C:\\Go_project\\cc.txt");
                BufferedWriter writer = new BufferedWriter(new FileWriter(out));
                writer.write(str.toString());
                writer.close();
            } else {
                //Output file of Go ID and their Parents of bp
                if (name == "namespace: biological_process") {
                    out = new File("C:\\Go_project\\bp.txt");
                    BufferedWriter writer = new BufferedWriter(new FileWriter(out));
                    writer.write(str.toString());
                    writer.close();
                } else {
                    //Output file of Go ID and their Parents of mf
                    if (name == "namespace: molecular_function") {
                        out = new File("C:\\Go_project\\mf.txt");
                        BufferedWriter writer = new BufferedWriter(new FileWriter(out));
                        writer.write(str.toString());
                        writer.close();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("File write completed");

    }

    public static String mapToString(Map<String, List<String>> map) {
        StringBuilder stringBuilder = new StringBuilder();
        //Map to corresponding Parent term
        for (String key : map.keySet()) {
            List<String> values = map.get(key);
            stringBuilder.append((key));
            stringBuilder.append("=");
            StringBuffer Val = new StringBuffer();
            if (values.size() > 0) {
                Val.append(values.get(0));
                for (int i = 1; i < values.size(); i++) {
                    Val.append(",");
                    Val.append(values.get(i));
                }
                stringBuilder.append(Val + "\n");

            } else {
                stringBuilder.append("\n");
            }

        }

        return stringBuilder.toString();
    }

    public static void main(String[] args) throws FileNotFoundException {
        FindParent mf = new FindParent();
        FindParent bp = new FindParent();
        FindParent cc = new FindParent();
        mf.FileSeperate("namespace: molecular_function");
        bp.FileSeperate("namespace: biological_process");
        cc.FileSeperate("namespace: cellular_component");

    }

}