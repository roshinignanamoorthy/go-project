import java.io.*;

public class Merge {

    public static void main(String[] args) throws IOException {
        // PrintWriter object for Mergefiles.txt
        PrintWriter pw = new PrintWriter("C:\\Go_project\\Mergefiles.txt");

        // BufferedReader object for bp,mf,cc.txt
        BufferedReader br1 = new BufferedReader(new FileReader("C:\\Go_project\\bp.txt"));
        BufferedReader br2 = new BufferedReader(new FileReader("C:\\Go_project\\mf.txt"));
        BufferedReader br3 = new BufferedReader(new FileReader("C:\\Go_project\\cc.txt"));

        String line1 = br1.readLine();
        String line2 = br2.readLine();
        String line3 = br2.readLine();

        // loop to copy lines of all the txt files
        while (line1 != null || line2 != null || line3 != null) {
            if (line1 != null) {
                pw.println(line1);
                line1 = br1.readLine();
            }

            if (line2 != null) {
                pw.println(line2);
                line2 = br2.readLine();
            }
            if (line3 != null) {
                pw.println(line3);
                line3 = br3.readLine();
            }
        }

        pw.flush();

        // closing resources
        br1.close();
        br2.close();
        br3.close();
        pw.close();

        System.out.println("Merged all the files");
    }
}